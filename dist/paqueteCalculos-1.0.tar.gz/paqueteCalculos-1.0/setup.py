from setuptools import setup

setup(

	name="paqueteCalculos",
	version="1.0",
	description="Paquete de redondeo y potencia - Práctica Paquetes Distribuibles",
	author="me",
	author_email="",
	url=["calculos_paquetes","calculos_paquetes.redondeo_potencia"]
	
	)